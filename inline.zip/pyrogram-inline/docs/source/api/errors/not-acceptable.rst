406 - NotAcceptable
-------------------

.. csv-table::
    :file: ../../../../compiler/errors/source/406_NOT_ACCEPTABLE.tsv
    :delim: tab
    :header-rows: 1